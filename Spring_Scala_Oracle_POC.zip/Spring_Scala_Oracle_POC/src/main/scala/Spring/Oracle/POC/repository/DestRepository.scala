package Spring.Oracle.POC.repository
import java.sql.Date
import java.util

import Spring.Oracle.POC.model.DestModel
import org.springframework.data.jpa.repository.{JpaRepository, Query}
import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
trait DestRepository extends JpaRepository[DestModel,Long]{


  @Query(value = "select * from dqm_sample where dq_project_id > :id",nativeQuery = true)
  def querydata(id : Int):util.Collection[DestModel]

}
