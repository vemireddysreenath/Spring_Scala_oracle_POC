package Spring.Oracle.POC.model

import java.sql.Date

import javax.persistence._
import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.context.annotation.Bean

import scala.language.postfixOps

@Bean
@Entity
@Table(name = "edc_dq_err")
@EnableAutoConfiguration
class SourceModel {
  //DQ_PROJECT_ID
  @Id
  var dq_project_id : Long = _
  def getDq_project_id = dq_project_id
  def setDq_prokect_id(dq_project_id : Long) = this.dq_project_id = dq_project_id

  //RULE_ID
  var rule_id : Long = _
  def getRule_id :Long = rule_id
  def setRule_id(rule_id : Long) = this.rule_id = rule_id

  //VERSION_NUMBER
  var version_number : Long = _
  def getVersion_number :Long = rule_id
  def setVersion_number(version_number : Long) = this.version_number = version_number
  //ERROR_ID
  var error_id :Long= _
  def getError_id = error_id
  def setError_id(error_id : Long) = this.error_id=error_id
  //ERROR_DATE_OF_RUN
  var error_date_of_run : Date = _
  def getError_date_of_run = error_date_of_run
  def setError_date_of_run(error_date_of_run : Date) = this.error_date_of_run = error_date_of_run
  //DATA_THEME_ID
  var data_theme_id : Long = _
  def getData_theme_id = data_theme_id
  def setData_theme_id(data_theme_id : Long) = this.data_theme_id = data_theme_id
  //BUSINESS_THEME_ID
  var business_theme_id :Long = _
  def getBusiness_theme_id = business_theme_id
  def setBusiness_theme_id(business_theme_id : Long) = this.business_theme_id = business_theme_id
  //ENTITY_NAME
  var entity_name : String = _
  def getEntity_name = entity_name
  def setEntity_name(entity_name : String) = this.entity_name = entity_name
  //RECORD_ID
  var record_id : Long = _
  def getRecord_id = record_id
  def setRecord_id(record_id : Long) = this.record_id = record_id
  //ERROR_FLAG
  var error_flag : String = _
  def getError_flag = error_flag
  def setError_flag(error_flag : String) = this.error_flag = error_flag

}
