package Spring.Oracle.POC.repository

import Spring.Oracle.POC.model.EntityModel
import org.springframework.data.jpa.repository.JpaRepository

trait TabRepository extends JpaRepository[EntityModel,Long]{

}
