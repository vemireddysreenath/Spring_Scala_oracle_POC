package Spring.Oracle.POC.controller

import java.io.PrintWriter
import java.util.{Calendar, List}

import Spring.Oracle.POC.model.{DestModel, EntityModel}
import Spring.Oracle.POC.repository.{DestRepository, TabRepository}
import org.springframework.web.bind.annotation._
import java.io.FileWriter
import java.sql.Date
import java.util

import com.opencsv.CSVWriter
import com.opencsv.bean.{StatefulBeanToCsv, StatefulBeanToCsvBuilder}
import javax.servlet.http.HttpServletResponse
import javax.validation.Valid
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders


@RestController
@RequestMapping(Array("/api"))
class TabController(@Autowired tabRepository: TabRepository, @Autowired destRepository: DestRepository) {

    @GetMapping(Array("/getsource"))
    def getWholeTab : List[EntityModel] = {println("Full table printed");tabRepository.findAll()}


    @GetMapping(Array("/put"))
    def uploadData:String = {
      val entityTab = tabRepository.findAll().iterator()
      while(entityTab.hasNext){
        val fields = entityTab.next()
        val dq_project_id : Long= fields.dq_project_id.toLong+8
        val entity_name : String = fields.entity_name.toString
        val error_date_of_run: Date = fields.error_date_of_run
        val destModel = new DestModel
        destModel.setDq_project_id(dq_project_id)
        destModel.setEntity_name(entity_name)
        destModel.setError_date_of_run(error_date_of_run)
        destRepository.save(destModel)
      }
      return "Data Transfer is completed"
    }

    @GetMapping(Array("/getdest"))
    def getDestTab : List[DestModel] = destRepository.findAll()

    @PostMapping(Array("/getdest"))
    def updateField(@Valid @RequestBody destModel: DestModel)= {
      destRepository.save(destModel)
    }

    @PutMapping(Array("/getdest"))
    def addField(@Valid @RequestBody destModel: DestModel)= {
      destRepository.save(destModel)
    }

  /*
  @PutMapping(Array("/posts/{postId}"))
  def updatePost(@PathVariable postId: Long, @Valid @RequestBody postRequest: Nothing): Nothing =
          postRepository.findById(postId).map((post) => {
    def foo(post) = {
      post.setTitle(postRequest.getTitle)
      post.setDescription(postRequest.getDescription)
      post.setContent(postRequest.getContent)
      postRepository.save(post)
    }

    foo(post)
  })*/

  //@PostMapping(Array("/notes"))
  //def createNote(@Valid @RequestBody note: Note): Note = noteRepository.save(note)


    @GetMapping(Array("/{getDq_project_id}"))
    def getById(@PathVariable("getDq_project_id") getDq_project_id: Long) =tabRepository.findById(getDq_project_id)

    /*@GetMapping(Array("/downFile"))
    def downloadFile  = {
            var data = tabRepository.findAll
            var pw = new PrintWriter("/sample11.txt")
            pw.print(data)
            pw.close()
    }*/

   @GetMapping(Array("/downloadsource"))
    def downloadFile1(response : HttpServletResponse):Unit  = {
            val filename = new FileWriter("users.csv")
            response.setContentType("text/csv")
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
            val writer : StatefulBeanToCsv[EntityModel]= {
                        new StatefulBeanToCsvBuilder[EntityModel](response.getWriter)
                        .withQuotechar(CSVWriter.NO_QUOTE_CHARACTER).withSeparator('\t').build()
            }
            writer.write(getWholeTab)

   }
}