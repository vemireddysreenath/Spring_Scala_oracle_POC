package Spring.Oracle.POC.model

import java.sql.{Date, Timestamp}

import javax.persistence._
import oracle.net.aso.d
import org.springframework.context.annotation.Bean



@Bean
@Entity
@Table(name = "dqm_sample")
class DestModel{

  @Id
  var dq_project_id : Long = _

  var entity_name : String = _

  var error_date_of_run : Date = _


  def getDq_project_id = dq_project_id
  def setDq_project_id(dq_project_id : Long) = this.dq_project_id = dq_project_id


  def getEntity_name = entity_name
  def setEntity_name(entity_name : String) = this.entity_name = entity_name

  //ERROR_DATE_OF_RUN

  def getError_date_of_run = error_date_of_run
  def setError_date_of_run(error_date_of_run : Date) = this.error_date_of_run = error_date_of_run

}
