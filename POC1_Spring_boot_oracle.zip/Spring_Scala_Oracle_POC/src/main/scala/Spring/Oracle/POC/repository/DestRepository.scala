package Spring.Oracle.POC.repository
import Spring.Oracle.POC.model.DestModel
import org.springframework.data.jpa.repository.JpaRepository

trait DestRepository extends JpaRepository[DestModel,Long]{

}
