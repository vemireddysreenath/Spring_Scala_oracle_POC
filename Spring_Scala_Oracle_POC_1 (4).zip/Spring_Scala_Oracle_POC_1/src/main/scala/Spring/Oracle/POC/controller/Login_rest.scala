//package Spring.Oracle.POC.controller
//
//import org.springframework.stereotype.Controller
//
//
//@Controller
//class Login_rest {
//
//  import org.springframework.web.bind.annotation.RequestMapping
//  import org.springframework.web.bind.annotation.RequestMethod
//  import org.springframework.web.bind.annotation.RequestParam
//  import org.springframework.web.servlet.ModelAndView
//
//  @RequestMapping(value = Array("/login"), method = Array(RequestMethod.GET))
//  def login()="login"
//
//}
