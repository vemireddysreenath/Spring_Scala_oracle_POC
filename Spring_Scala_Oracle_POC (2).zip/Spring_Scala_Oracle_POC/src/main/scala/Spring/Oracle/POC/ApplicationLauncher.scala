package Spring.Oracle.POC



import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.SpringApplication

@SpringBootApplication
class ApplicationLauncher
object ApplicationLauncher extends App {
  SpringApplication.run(classOf[ApplicationLauncher])
}