package Spring.Oracle.POC.controller

import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.{RequestMapping, RestController}

@Controller
class WelcomeNote {
  @RequestMapping(Array("/"))
  def welcome(model: Model) :String ={
    model.addAttribute("message","Welcome to spring boot Application")
    "welcome"
  }

}
