package Spring.Oracle.POC.controller

import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.{GetMapping, RequestMapping}

@Controller
@RequestMapping(Array("/"))
class WelcomeNote {
  @GetMapping(Array(""))
  def welcome :String = "welcome"





//  @GetMapping(Array("login"))
//  def login(model: Model, error: String, logout: String): String = {
//    if (error != null) model.addAttribute("error", "Your username and password is invalid.")
//    if (logout != null) model.addAttribute("message", "You have been logged out successfully.")
//    "login"
//  }

}
