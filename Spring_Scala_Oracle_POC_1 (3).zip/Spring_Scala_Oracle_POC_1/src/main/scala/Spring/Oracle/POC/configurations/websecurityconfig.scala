package Spring.Oracle.POC.configurations

import java.util

import org.springframework.context.annotation.{Bean, ComponentScan, Configuration}
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter
import org.springframework.security.core.userdetails.{User, UserDetails, UserDetailsService}
import org.springframework.security.provisioning.InMemoryUserDetailsManager
import org.springframework.web.servlet.config.annotation.EnableWebMvc


@Configuration
@EnableWebSecurity
class websecurityconfig extends WebSecurityConfigurerAdapter{


//  override def configure(http: HttpSecurity): Unit = {
//    http.authorizeRequests
//      .antMatchers("/**").hasAnyRole("USER")
//      .and()
//      .formLogin()
//        .loginPage("/login")
//        .permitAll()
//        .and()
//      .logout()
//        .permitAll()
//      .and().csrf().disable().headers().frameOptions().disable()
//  }


  @Bean
  override
  protected def userDetailsService(): UserDetailsService = {
    var users: util.List[UserDetails] = new util.ArrayList[UserDetails]
    users.add(User.withDefaultPasswordEncoder().username("admin").password("password2").roles("ADMIN").build())
    users.add(User.withDefaultPasswordEncoder().username("user1").password("password2").roles("USER").build())
    users.add(User.withDefaultPasswordEncoder().username("user2").password("password2").roles("USER").build())

    new InMemoryUserDetailsManager(users)

  }

//  override
//  def configure(auth: AuthenticationManagerBuilder): Unit = {
//    auth.inMemoryAuthentication()
//      .withUser("user1").password("{noop}password2").roles("USER")
//
//  }

//  override
//  def configure(http: HttpSecurity): Unit = {
//    http.csrf().disable()
//    http.authorizeRequests()
//      .antMatchers("/").authenticated()
//      .anyRequest().permitAll()
//      .and().formLogin().permitAll()
//  }


  //Working
  override def configure(http: HttpSecurity): Unit = {
    http.httpBasic().and().authorizeRequests()
      .antMatchers("/**").hasAnyRole("USER")
      .antMatchers("**/saverecord").hasRole("ADMIN")
      .and().csrf().disable().headers().frameOptions().disable()
  }




}


