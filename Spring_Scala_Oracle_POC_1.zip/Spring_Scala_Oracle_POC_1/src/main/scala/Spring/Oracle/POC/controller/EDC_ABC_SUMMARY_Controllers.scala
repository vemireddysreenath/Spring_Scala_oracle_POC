package Spring.Oracle.POC.controller

import Spring.Oracle.POC.DestDB.model.EDC_ABC_SUMMARY_Model
import Spring.Oracle.POC.DestDB.repository.EDC_ABC_SUMMARY_Repository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.validation.BindingResult
import org.springframework.web.bind.annotation._


@Controller
@RequestMapping(Array("/edcabcsummary"))
class EDC_ABC_SUMMARY_Controllers(@Autowired eDC_ABC_SUMMARY_Repository: EDC_ABC_SUMMARY_Repository) {

  @GetMapping(Array(""))
  def wecomenote(model: Model):String={
    model.addAttribute("mode","EDC_ABC_SUMMARY")
    "welcome"
  }

  @GetMapping(Array("/get"))
  def getall(model:Model)={
    model.addAttribute("edcabcsummary",eDC_ABC_SUMMARY_Repository.findAll)
    model.addAttribute("mode","EDC_ABC_SUMMARY")
    "tabview"
  }

  @GetMapping(Array("/addrecord"))
  def registration(model: Model): String = {
    model.addAttribute("mode", "EDC_ABC_SUMMARY_ADD_RECORD")
    "addrecord"
  }
  @PostMapping(Array("/saverecord"))
  def addRecord(@ModelAttribute("edcrecord") edcrecord:EDC_ABC_SUMMARY_Model,model: Model, bindingResult: BindingResult) = {
    eDC_ABC_SUMMARY_Repository.save(edcrecord)
    model.addAttribute("mode","EDC_ABC_SUMMARY_SAVE_RECORD")
    "addrecord"
  }

  @GetMapping(Array("/logic"))
  def logic(model : Model) ={
    model.addAttribute("edcabcsummary",eDC_ABC_SUMMARY_Repository.logic)
    model.addAttribute("mode","EDC_ABC_SUMMARY")
    "tabview"
  }

  @GetMapping(Array("/upload"))
  def load(model: Model):String = {
    eDC_ABC_SUMMARY_Repository.logic.forEach(data => eDC_ABC_SUMMARY_Repository.load(data.rule_id,data.rule_name,data.rule_desc,
      data.m1_total_count,data.m1_error_count,data.m2_total_count,data.m2_error_count,
      data.m3_total_count,data.m3_error_count,data.m4_total_count,data.m4_error_count,
      data.m5_total_count,data.m5_error_count,data.m6_total_count,data.m6_error_count))
    model.addAttribute("edcabcsummary",eDC_ABC_SUMMARY_Repository.findAll)
    getall(model:Model)
  }

  @DeleteMapping(Array("/truncate"))
  def truncate:String={
    eDC_ABC_SUMMARY_Repository.deleteAllInBatch()
    "All records are deleted from EDC_ABC_SUMMARY"
  }

  @GetMapping(value = Array("/delete"))
  def delete(@RequestParam rule_id:Long,model: Model):String={
    eDC_ABC_SUMMARY_Repository.deleteById(rule_id)
    getall(model:Model)
  }


}
