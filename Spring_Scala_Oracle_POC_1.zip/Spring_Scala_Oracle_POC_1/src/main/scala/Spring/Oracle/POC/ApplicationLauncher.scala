package Spring.Oracle.POC



import org.springframework.boot.autoconfigure.{EnableAutoConfiguration, SpringBootApplication}
import org.springframework.boot.SpringApplication

@SpringBootApplication
@EnableAutoConfiguration
class ApplicationLauncher
object ApplicationLauncher extends App {
  SpringApplication.run(classOf[ApplicationLauncher])
}